// Product comparison functionality
document.addEventListener('DOMContentLoaded', function () {
    initComparisonPage();
});

function initComparisonPage() {
    const product1Select = document.getElementById('product1');
    const product2Select = document.getElementById('product2');
    const compareButton = document.getElementById('compare-button');
    const comparisonResults = document.getElementById('comparison-results');
    const nutritionalComparison = document.getElementById('nutritional-comparison');
    const categoryTabs = document.querySelectorAll('.category-tab');

    // Skip if we're not on the comparison page
    if (!product1Select || !product2Select || !compareButton) return;
    
    // Event listeners
    compareButton.addEventListener('click', compareProducts);
    
    categoryTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs
            categoryTabs.forEach(t => t.classList.remove('active'));
            // Add active class to clicked tab
            tab.classList.add('active');
            
            // Filter products based on selected category
            const category = tab.id.replace('category-', '');
            filterProductsByCategory(category);
        });
    });
}

// Product data (simplified)
// Product database with nutritional and additional information
const productDatabase = {
    // FRUITS
    cavendish_banana: {
        name: "Premium Cavendish Banana",
        category: "fruits",
        price: "₱89.50",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 88,
        ratings: "8,245",
        flavors: ["Sweet", "Mild", "Creamy"],
        nutrition: {
            calories: 105,
            protein: 1.3,
            carbs: 27,
            fats: 0.3,
            vitamins: 8.7,
            minerals: 7.5,
            overall: 8.5
        },
        details: {
            origin: "Philippines",
            shelfLife: "5-7 days",
            servingSize: "118g (1 medium)",
            ingredients: "100% Natural Banana",
            packaging: "Eco-friendly Mesh Bag"
        },
        benchmarks: {
            good: "Great natural sugar: 14g (natural sugar)",
            poor: "Low protein: 1.3g per fruit"
        }
    },
    lacatan_banana: {
        name: "Premium Lacatan Banana",
        category: "fruits",
        price: "₱95.50",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 92,
        ratings: "7,812",
        flavors: ["Sweet", "Rich", "Aromatic"],
        nutrition: {
            calories: 110,
            protein: 1.5,
            carbs: 28,
            fats: 0.4,
            vitamins: 9.2,
            minerals: 8.0,
            overall: 9.0
        },
        details: {
            origin: "Philippines",
            shelfLife: "5-7 days",
            servingSize: "120g (1 medium)",
            ingredients: "100% Natural Banana",
            packaging: "Eco-friendly Mesh Bag"
        },
        benchmarks: {
            good: "High potassium: 450mg per fruit",
            poor: "Low protein: 1.5g per fruit"
        }
    },
    saba_banana: {
        name: "Premium Saba Banana",
        category: "fruits",
        price: "₱75.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 85,
        ratings: "9,123",
        flavors: ["Starchy", "Mild Sweet", "Versatile"],
        nutrition: {
            calories: 115,
            protein: 1.3,
            carbs: 30,
            fats: 0.2,
            vitamins: 7.5,
            minerals: 8.2,
            overall: 8.0
        },
        details: {
            origin: "Philippines",
            shelfLife: "7-10 days",
            servingSize: "125g (1 medium)",
            ingredients: "100% Natural Banana",
            packaging: "Eco-friendly Mesh Bag"
        },
        benchmarks: {
            good: "Great for cooking: Starch converts to sugar when cooked",
            poor: "Higher carbs: 30g per serving"
        }
    },
    latundan_banana: {
        name: "Premium Latundan Banana",
        category: "fruits",
        price: "₱92.50",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 90,
        ratings: "6,987",
        flavors: ["Sweet", "Aromatic", "Tangy"],
        nutrition: {
            calories: 100,
            protein: 1.4,
            carbs: 26,
            fats: 0.3,
            vitamins: 9.0,
            minerals: 7.8,
            overall: 8.8
        },
        details: {
            origin: "Philippines",
            shelfLife: "4-6 days",
            servingSize: "110g (1 medium)",
            ingredients: "100% Natural Banana",
            packaging: "Eco-friendly Mesh Bag"
        },
        benchmarks: {
            good: "Excellent flavor profile: Rated 9.2/10",
            poor: "Shorter shelf life: 4-6 days"
        }
    },
    red_banana: {
        name: "Premium Red Banana",
        category: "fruits",
        price: "₱115.00",
        release: "Seasonal",
        image: "/api/placeholder/200/150",
        score: 95,
        ratings: "5,432",
        flavors: ["Sweet", "Raspberry Notes", "Creamy"],
        nutrition: {
            calories: 110,
            protein: 1.6,
            carbs: 27,
            fats: 0.4,
            vitamins: 9.8,
            minerals: 8.5,
            overall: 9.2
        },
        details: {
            origin: "Philippines - Specialty Farms",
            shelfLife: "3-5 days",
            servingSize: "115g (1 medium)",
            ingredients: "100% Natural Banana",
            packaging: "Premium Eco-friendly Box"
        },
        benchmarks: {
            good: "Higher antioxidants: 120% more than Cavendish",
            poor: "Limited availability: Seasonal only"
        }
    },

    // CHIPS
    lays_classic: {
        name: "Lay's Classic Potato Chips",
        category: "chips",
        price: "₱89.00",
        release: "Q1 2020",
        image: "/api/placeholder/200/150",
        score: 83,
        ratings: "15,678",
        flavors: ["Original", "Salted", "Classic"],
        nutrition: {
            calories: 160,
            protein: 2,
            carbs: 15,
            fats: 10,
            vitamins: 1,
            minerals: 3,
            overall: 4.5
        },
        details: {
            origin: "Imported",
            shelfLife: "6-8 months",
            servingSize: "28g (about 15 chips)",
            ingredients: "Potatoes, Vegetable Oil, Salt",
            packaging: "Plastic Bag"
        },
        benchmarks: {
            good: "Light and crispy texture: 9/10 rating",
            poor: "High sodium: 170mg per serving"
        }
    },
    lays_bbq: {
        name: "Lay's Barbecue Flavored Chips",
        category: "chips",
        price: "₱95.00",
        release: "Q2 2020",
        image: "/api/placeholder/200/150",
        score: 85,
        ratings: "12,345",
        flavors: ["Barbecue", "Smoky", "Sweet"],
        nutrition: {
            calories: 160,
            protein: 2,
            carbs: 16,
            fats: 10,
            vitamins: 1,
            minerals: 3,
            overall: 4.3
        },
        details: {
            origin: "Imported",
            shelfLife: "6-8 months",
            servingSize: "28g (about 15 chips)",
            ingredients: "Potatoes, Vegetable Oil, BBQ Seasoning (contains artificial flavors)",
            packaging: "Plastic Bag"
        },
        benchmarks: {
            good: "Bold flavor profile: 9.2/10 rating",
            poor: "Artificial ingredients: Contains 4 artificial additives"
        }
    },
    lays_sv: {
        name: "Lay's Salt & Vinegar Chips",
        category: "chips",
        price: "₱95.00",
        release: "Q3 2020",
        image: "/api/placeholder/200/150",
        score: 82,
        ratings: "10,876",
        flavors: ["Tangy", "Sour", "Salty"],
        nutrition: {
            calories: 160,
            protein: 2,
            carbs: 15,
            fats: 10,
            vitamins: 1,
            minerals: 3,
            overall: 4.2
        },
        details: {
            origin: "Imported",
            shelfLife: "6-8 months",
            servingSize: "28g (about 15 chips)",
            ingredients: "Potatoes, Vegetable Oil, Salt & Vinegar Seasoning",
            packaging: "Plastic Bag"
        },
        benchmarks: {
            good: "Intense flavor: 9.5/10 for tanginess",
            poor: "May cause mouth irritation with excessive consumption"
        }
    },
    lays_wavy: {
        name: "Lay's Wavy Potato Chips",
        category: "chips",
        price: "₱99.00",
        release: "Q4 2020",
        image: "/api/placeholder/200/150",
        score: 87,
        ratings: "9,876",
        flavors: ["Original", "Salted", "Crunchy"],
        nutrition: {
            calories: 160,
            protein: 2,
            carbs: 15,
            fats: 10,
            vitamins: 1,
            minerals: 3,
            overall: 4.4
        },
        details: {
            origin: "Imported",
            shelfLife: "6-8 months",
            servingSize: "28g (about 13 chips)",
            ingredients: "Potatoes, Vegetable Oil, Salt",
            packaging: "Plastic Bag"
        },
        benchmarks: {
            good: "Extra crunch: Thicker cut for more substantial bite",
            poor: "Slightly higher fat content due to ridges"
        }
    },
    lays_baked: {
        name: "Lay's Baked Potato Chips",
        category: "chips",
        price: "₱105.00",
        release: "Q1 2021",
        image: "/api/placeholder/200/150",
        score: 88,
        ratings: "8,765",
        flavors: ["Original", "Light", "Baked"],
        nutrition: {
            calories: 120,
            protein: 2,
            carbs: 23,
            fats: 3,
            vitamins: 1,
            minerals: 3,
            overall: 6.5
        },
        details: {
            origin: "Imported",
            shelfLife: "5-7 months",
            servingSize: "28g (about 17 chips)",
            ingredients: "Potatoes, Corn Starch, Sugar, Corn Oil, Salt",
            packaging: "Plastic Bag"
        },
        benchmarks: {
            good: "65% less fat than regular chips",
            poor: "Slightly different texture than traditional chips"
        }
    },
    lays_kettle: {
        name: "Lay's Kettle Cooked Chips",
        category: "chips",
        price: "₱110.00",
        release: "Q2 2021",
        image: "/api/placeholder/200/150",
        score: 90,
        ratings: "7,654",
        flavors: ["Original", "Hearty", "Extra Crunchy"],
        nutrition: {
            calories: 150,
            protein: 2,
            carbs: 15,
            fats: 9,
            vitamins: 1,
            minerals: 3,
            overall: 4.7
        },
        details: {
            origin: "Imported",
            shelfLife: "7-9 months",
            servingSize: "28g (about 14 chips)",
            ingredients: "Potatoes, Vegetable Oil, Sea Salt",
            packaging: "Thick Plastic Bag"
        },
        benchmarks: {
            good: "Extra crunchy: Cooked in small batches",
            poor: "Higher calorie density per chip"
        }
    },
    
    // VEGETABLES
    organic_kale: {
        name: "Baguio Fresh Organic Kale",
        category: "vegetables",
        price: "₱120.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 95,
        ratings: "5,432",
        flavors: ["Earthy", "Slightly Bitter", "Fresh"],
        nutrition: {
            calories: 33,
            protein: 2.9,
            carbs: 6.7,
            fats: 0.5,
            vitamins: 9.8,
            minerals: 9.5,
            overall: 9.7
        },
        details: {
            origin: "Baguio, Philippines",
            shelfLife: "5-7 days",
            servingSize: "100g (about 2 cups chopped)",
            ingredients: "100% Organic Kale",
            packaging: "Eco-friendly Biodegradable Bag"
        },
        benchmarks: {
            good: "Extremely nutrient-dense: High in vitamins A, C, K",
            poor: "Requires thorough washing before use"
        }
    },
    conventional_kale: {
        name: "Baguio Fresh Conventional Kale",
        category: "vegetables",
        price: "₱90.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 88,
        ratings: "6,543",
        flavors: ["Earthy", "Bitter", "Fresh"],
        nutrition: {
            calories: 33,
            protein: 2.9,
            carbs: 6.7,
            fats: 0.5,
            vitamins: 9.4,
            minerals: 9.2,
            overall: 9.3
        },
        details: {
            origin: "Baguio, Philippines",
            shelfLife: "4-6 days",
            servingSize: "100g (about 2 cups chopped)",
            ingredients: "100% Natural Kale",
            packaging: "Plastic Bag"
        },
        benchmarks: {
            good: "More affordable: 25% less expensive than organic",
            poor: "May contain trace pesticide residues"
        }
    },
    baby_kale: {
        name: "Baguio Fresh Baby Kale",
        category: "vegetables",
        price: "₱135.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 92,
        ratings: "4,321",
        flavors: ["Mild", "Fresh", "Tender"],
        nutrition: {
            calories: 28,
            protein: 2.5,
            carbs: 5.9,
            fats: 0.4,
            vitamins: 9.6,
            minerals: 9.3,
            overall: 9.5
        },
        details: {
            origin: "Baguio, Philippines",
            shelfLife: "3-5 days",
            servingSize: "85g (about 3 cups)",
            ingredients: "100% Natural Baby Kale",
            packaging: "Plastic Container"
        },
        benchmarks: {
            good: "More tender: No need to remove stems",
            poor: "Shorter shelf life than mature kale"
        }
    },
    lacinato_kale: {
        name: "Baguio Fresh Lacinato Kale",
        category: "vegetables",
        price: "₱125.00",
        release: "Seasonal",
        image: "/api/placeholder/200/150",
        score: 93,
        ratings: "3,987",
        flavors: ["Earthy", "Nutty", "Sweet"],
        nutrition: {
            calories: 35,
            protein: 3.0,
            carbs: 7.0,
            fats: 0.5,
            vitamins: 9.7,
            minerals: 9.4,
            overall: 9.6
        },
        details: {
            origin: "Baguio, Philippines",
            shelfLife: "5-7 days",
            servingSize: "100g (about 2 cups chopped)",
            ingredients: "100% Natural Lacinato Kale",
            packaging: "Eco-friendly Biodegradable Bag"
        },
        benchmarks: {
            good: "Tender texture: Easier to eat raw than curly kale",
            poor: "Less widely available than regular kale"
        }
    },
    red_russian_kale: {
        name: "Baguio Fresh Red Russian Kale",
        category: "vegetables",
        price: "₱130.00",
        release: "Seasonal",
        image: "/api/placeholder/200/150",
        score: 91,
        ratings: "3,654",
        flavors: ["Mild", "Peppery", "Sweet"],
        nutrition: {
            calories: 32,
            protein: 3.2,
            carbs: 6.5,
            fats: 0.5,
            vitamins: 9.5,
            minerals: 9.3,
            overall: 9.4
        },
        details: {
            origin: "Baguio, Philippines",
            shelfLife: "4-6 days",
            servingSize: "100g (about 2 cups chopped)",
            ingredients: "100% Natural Red Russian Kale",
            packaging: "Eco-friendly Biodegradable Bag"
        },
        benchmarks: {
            good: "Milder flavor: Great for kale beginners",
            poor: "More delicate: Bruises more easily"
        }
    },
    
    // BEVERAGES
    pure_coconut_water: {
        name: "Coco Earth Pure Coconut Water",
        category: "beverages",
        price: "₱85.00",
        release: "Q1 2022",
        image: "/api/placeholder/200/150",
        score: 90,
        ratings: "8,765",
        flavors: ["Natural", "Slightly Sweet", "Fresh"],
        nutrition: {
            calories: 45,
            protein: 1.7,
            carbs: 11,
            fats: 0.5,
            vitamins: 7.8,
            minerals: 9.2,
            overall: 8.5
        },
        details: {
            origin: "Philippines",
            shelfLife: "12 months sealed, 3-5 days after opening",
            servingSize: "240ml (1 cup)",
            ingredients: "100% Pure Coconut Water",
            packaging: "Tetra Pak"
        },
        benchmarks: {
            good: "High in electrolytes: 600mg potassium per serving",
            poor: "Natural sugar content: 11g per serving"
        }
    },
    coconut_water_pulp: {
        name: "Coco Earth Coconut Water with Pulp",
        category: "beverages",
        price: "₱95.00",
        release: "Q2 2022",
        image: "/api/placeholder/200/150",
        score: 87,
        ratings: "7,654",
        flavors: ["Natural", "Sweet", "Coconut Bits"],
        nutrition: {
            calories: 55,
            protein: 1.9,
            carbs: 13,
            fats: 0.8,
            vitamins: 7.9,
            minerals: 9.0,
            overall: 8.3
        },
        details: {
            origin: "Philippines",
            shelfLife: "12 months sealed, 3-5 days after opening",
            servingSize: "240ml (1 cup)",
            ingredients: "Coconut Water, Coconut Pulp",
            packaging: "Tetra Pak"
        },
        benchmarks: {
            good: "Added fiber: 2g fiber from coconut pulp",
            poor: "Higher calorie count than pure version"
        }
    },
    no_sugar_coconut_water: {
        name: "Coco Earth No Sugar Added Coconut Water",
        category: "beverages",
        price: "₱90.00",
        release: "Q3 2022",
        image: "/api/placeholder/200/150",
        score: 88,
        ratings: "6,543",
        flavors: ["Natural", "Light", "Refreshing"],
        nutrition: {
            calories: 40,
            protein: 1.7,
            carbs: 9,
            fats: 0.5,
            vitamins: 7.8,
            minerals: 9.2,
            overall: 8.4
        },
        details: {
            origin: "Philippines",
            shelfLife: "12 months sealed, 3-5 days after opening",
            servingSize: "240ml (1 cup)",
            ingredients: "100% Pure Coconut Water (no added sugar)",
            packaging: "Tetra Pak"
        },
        benchmarks: {
            good: "Lower sugar: Only natural coconut sugars",
            poor: "Slightly less sweet taste than regular version"
        }
    },
    king_coconut_water: {
        name: "Coco Earth King Coconut Water",
        category: "beverages",
        price: "₱110.00",
        release: "Q1 2023",
        image: "/api/placeholder/200/150",
        score: 94,
        ratings: "5,432",
        flavors: ["Sweet", "Rich", "Premium"],
        nutrition: {
            calories: 48,
            protein: 1.8,
            carbs: 12,
            fats: 0.5,
            vitamins: 8.2,
            minerals: 9.5,
            overall: 8.9
        },
        details: {
            origin: "Philippines - Premium Farms",
            shelfLife: "10 months sealed, 3-5 days after opening",
            servingSize: "240ml (1 cup)",
            ingredients: "100% King Coconut Water",
            packaging: "Premium Glass Bottle"
        },
        benchmarks: {
            good: "Superior taste: Naturally sweeter than regular coconut water",
            poor: "Premium price: 30% more expensive than regular"
        }
    },
    organic_coconut_water: {
        name: "Coco Earth Organic Coconut Water",
        category: "beverages",
        price: "₱105.00",
        release: "Q2 2023",
        image: "/api/placeholder/200/150",
        score: 92,
        ratings: "4,987",
        flavors: ["Pure", "Natural", "Clean"],
        nutrition: {
            calories: 45,
            protein: 1.7,
            carbs: 11,
            fats: 0.5,
            vitamins: 8.0,
            minerals: 9.3,
            overall: 8.7
        },
        details: {
            origin: "Philippines - Organic Certified Farms",
            shelfLife: "12 months sealed, 3-5 days after opening",
            servingSize: "240ml (1 cup)",
            ingredients: "100% Organic Certified Coconut Water",
            packaging: "Eco-friendly Tetra Pak"
        },
        benchmarks: {
            good: "Organic certified: No pesticides or chemicals",
            poor: "Higher price point than conventional"
        }
    },
    
    // DAIRY
    plain_greek_yogurt: {
        name: "Grassland Farms Plain Greek Yogurt",
        category: "dairy",
        price: "₱120.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 92,
        ratings: "9,876",
        flavors: ["Tangy", "Creamy", "Rich"],
        nutrition: {
            calories: 120,
            protein: 17,
            carbs: 5,
            fats: 5,
            vitamins: 7.5,
            minerals: 8.5,
            overall: 9.0
        },
        details: {
            origin: "Local Dairy Farm",
            shelfLife: "21 days sealed, 5-7 days after opening",
            servingSize: "170g (6 oz)",
            ingredients: "Pasteurized Milk, Live Active Cultures",
            packaging: "Plastic Container"
        },
        benchmarks: {
            good: "High protein: 17g per serving",
            poor: "Tangy flavor may be too strong for some"
        }
    },
    low_fat_yogurt: {
        name: "Grassland Farms Low Fat Yogurt",
        category: "dairy",
        price: "₱110.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 88,
        ratings: "8,765",
        flavors: ["Mild", "Creamy", "Light"],
        nutrition: {
            calories: 100,
            protein: 12,
            carbs: 7,
            fats: 2.5,
            vitamins: 7.0,
            minerals: 8.0,
            overall: 8.5
        },
        details: {
            origin: "Local Dairy Farm",
            shelfLife: "21 days sealed, 5-7 days after opening",
            servingSize: "170g (6 oz)",
            ingredients: "Pasteurized Low-Fat Milk, Live Active Cultures",
            packaging: "Plastic Container"
        },
        benchmarks: {
            good: "Lower fat: 50% less fat than regular yogurt",
            poor: "Less creamy texture than full-fat yogurt"
        }
    },
    non_fat_yogurt: {
        name: "Grassland Farms Non-Fat Yogurt",
        category: "dairy",
        price: "₱105.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 85,
        ratings: "7,654",
        flavors: ["Tangy", "Light", "Clean"],
        nutrition: {
            calories: 80,
            protein: 13,
            carbs: 8,
            fats: 0,
            vitamins: 6.5,
            minerals: 7.5,
            overall: 8.0
        },
        details: {
            origin: "Local Dairy Farm",
            shelfLife: "21 days sealed, 5-7 days after opening",
            servingSize: "170g (6 oz)",
            ingredients: "Pasteurized Skim Milk, Live Active Cultures",
            packaging: "Plastic Container"
        },
        benchmarks: {
            good: "Fat-free: 0g fat per serving",
            poor: "Less satisfying: May leave you hungry sooner"
        }
    },
    honey_yogurt: {
        name: "Grassland Farms Honey Yogurt",
        category: "dairy",
        price: "₱130.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 90,
        ratings: "9,543",
        flavors: ["Sweet", "Honey", "Creamy"],
        nutrition: {
            calories: 150,
            protein: 12,
            carbs: 18,
            fats: 4.5,
            vitamins: 7.0,
            minerals: 8.0,
            overall: 8.7
        },
        details: {
            origin: "Local Dairy Farm",
            shelfLife: "21 days sealed, 5-7 days after opening",
            servingSize: "170g (6 oz)",
            ingredients: "Pasteurized Milk, Pure Honey, Live Active Cultures",
            packaging: "Plastic Container"
        },
        benchmarks: {
            good: "Natural sweetener: Real honey instead of refined sugar",
            poor: "Higher sugar content: 12g per serving"
        }
    },
    mango_yogurt: {
        name: "Grassland Farms Mango Yogurt",
        category: "dairy",
        price: "₱135.00",
        release: "Seasonal",
        image: "/api/placeholder/200/150",
        score: 89,
        ratings: "8,765",
        flavors: ["Tropical", "Sweet", "Fruity"],
        nutrition: {
            calories: 140,
            protein: 11,
            carbs: 20,
            fats: 3.5,
            vitamins: 7.8,
            minerals: 7.5,
            overall: 8.6
        },
        details: {
            origin: "Local Dairy Farm",
            shelfLife: "18 days sealed, 5-7 days after opening",
            servingSize: "170g (6 oz)",
            ingredients: "Pasteurized Milk, Mango Puree, Cane Sugar, Live Active Cultures",
            packaging: "Plastic Container"
        },
        benchmarks: {
            good: "Real fruit: Contains actual mango puree",
            poor: "Added sugar: 13g added sugar per serving"
        }
    },
    
    // SNACKS
    classic_trail_mix: {
        name: "Nature Bites Superfood Trail Mix - Classic Blend",
        category: "snacks",
        price: "₱155.00",
        release: "Q3 2022",
        image: "/api/placeholder/200/150",
        score: 92,
        ratings: "7,654",
        flavors: ["Nutty", "Sweet", "Savory"],
        nutrition: {
            calories: 170,
            protein: 6,
            carbs: 14,
            fats: 12,
            vitamins: 6.5,
            minerals: 8.0,
            overall: 8.7
        },
        details: {
            origin: "Multiple Sources, Packaged in Philippines",
            shelfLife: "6 months sealed, 1 month after opening",
            servingSize: "30g (about 1/4 cup)",
            ingredients: "Almonds, Walnuts, Cashews, Raisins, Dried Cranberries, Dark Chocolate Chips",
            packaging: "Resealable Pouch"
        },
        benchmarks: {
            good: "Balanced nutrition: Good mix of protein, fiber, and healthy fats",
            poor: "Calorie-dense: High calories in small serving"
        }
    },
    tropical_trail_mix: {
        name: "Nature Bites Superfood Trail Mix - Tropical Mix",
        category: "snacks",
        price: "₱165.00",
        release: "Q4 2022",
        image: "/api/placeholder/200/150",
        score: 90,
        ratings: "6,543",
        flavors: ["Tropical", "Sweet", "Exotic"],
        nutrition: {
            calories: 160,
            protein: 5,
            carbs: 18,
            fats: 9,
            vitamins: 7.0,
            minerals: 7.5,
            overall: 8.5
        },
        details: {
            origin: "Multiple Sources, Packaged in Philippines",
            shelfLife: "5 months sealed, 3 weeks after opening",
            servingSize: "30g (about 1/4 cup)",
            ingredients: "Cashews, Dried Mango, Dried Pineapple, Coconut Chips, Banana Chips, Macadamia Nuts",
            packaging: "Resealable Pouch"
        },
        benchmarks: {
            good: "Exotic fruits: Contains real tropical fruits",
            poor: "Higher in sugar: 12g sugar per serving"
        }
    },
    energy_boost_trail_mix: {
        name: "Nature Bites Superfood Trail Mix - Energy Boost",
        category: "snacks",
        price: "₱175.00",
        release: "Q1 2023",
        image: "/api/placeholder/200/150",
        score: 94,
        ratings: "5,987",
        flavors: ["Nutty", "Chewy", "Energizing"],
        nutrition: {
            calories: 180,
            protein: 7,
            carbs: 16,
            fats: 13,
            vitamins: 7.5,
            minerals: 8.5,
            overall: 9.0
        },
        details: {
            origin: "Multiple Sources, Packaged in Philippines",
            shelfLife: "6 months sealed, 1 month after opening",
            servingSize: "30g (about 1/4 cup)",
            ingredients: "Almonds, Pumpkin Seeds, Goji Berries, Dark Chocolate Covered Espresso Beans, Dried Blueberries, Walnuts",
            packaging: "Resealable Pouch"
        },
        benchmarks: {
            good: "Natural energy boost: Contains natural caffeine from coffee beans",
            poor: "Premium price: 10% more expensive than classic mix"
        }
    },
    protein_plus_trail_mix: {
        name: "Nature Bites Superfood Trail Mix - Protein Plus",
        category: "snacks",
        price: "₱185.00",
        release: "Q2 2023",
        image: "/api/placeholder/200/150",
        score: 93,
        ratings: "5,432",
        flavors: ["Savory", "Nutty", "Roasted"],
        nutrition: {
            calories: 190,
            protein: 12,
            carbs: 12,
            fats: 14,
            vitamins: 6.5,
            minerals: 9.0,
            overall: 8.9
        },
        details: {
            origin: "Multiple Sources, Packaged in Philippines",
            shelfLife: "7 months sealed, 1 month after opening",
            servingSize: "30g (about 1/4 cup)",
            ingredients: "Roasted Edamame, Almonds, Pistachios, Peanuts, Pumpkin Seeds, Roasted Chickpeas",
            packaging: "Resealable Pouch"
        },
        benchmarks: {
            good: "High protein: 12g protein per serving",
            poor: "Higher calorie: 190 calories per small serving"
        }
    },
    low_sugar_trail_mix: {
        name: "Nature Bites Superfood Trail Mix - Low Sugar",
        category: "snacks",
        price: "₱165.00",
        release: "Q3 2023",
        image: "/api/placeholder/200/150",
        score: 91,
        ratings: "4,876",
        flavors: ["Savory", "Crunchy", "Lightly Sweet"],
        nutrition: {
            calories: 160,
            protein: 7,
            carbs: 8,
            fats: 13,
            vitamins: 6.0,
            minerals: 8.5,
            overall: 8.8
        },
        details: {
            origin: "Multiple Sources, Packaged in Philippines",
            shelfLife: "7 months sealed, 1 month after opening",
            servingSize: "30g (about 1/4 cup)",
            ingredients: "Almonds, Walnuts, Pecans, Hazelnuts, Coconut Chips, Cacao Nibs",
            packaging: "Resealable Pouch"
        },
        benchmarks: {
            good: "Low sugar: Only 2g of natural sugar per serving",
            poor: "Less variety: No dried fruits included"
        }
    },
    
    // MEATS
    chicken_breast_boneless: {
        name: "Boneless Skinless Chicken Breast",
        category: "meats",
        price: "₱275.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 90,
        ratings: "12,345",
        flavors: ["Mild", "Clean", "Lean"],
        nutrition: {
            calories: 165,
            protein: 31,
            carbs: 0,
            fats: 3.6,
            vitamins: 5.5,
            minerals: 7.0,
            overall: 9.0
        },
        details: {
            origin: "Local Farms",
            shelfLife: "2-3 days refrigerated, 6 months frozen",
            servingSize: "100g (3.5 oz)",
            ingredients: "100% Chicken Breast",
            packaging: "Vacuum Sealed Package"
        },
        benchmarks: {
            good: "High protein: 31g protein per serving",
            poor: "Can dry out easily if overcooked"
        }
    },
    chicken_thigh_bone_in: {
        name: "Bone-in Chicken Thigh",
        category: "meats",
        price: "₱225.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 88,
        ratings: "10,987",
        flavors: ["Rich", "Juicy", "Savory"],
        nutrition: {
            calories: 209,
            protein: 24,
            carbs: 0,
            fats: 13,
            vitamins: 6.0,
            minerals: 7.5,
            overall: 8.5
        },
        details: {
            origin: "Local Farms",
            shelfLife: "2-3 days refrigerated, 6 months frozen",
            servingSize: "100g (3.5 oz)",
            ingredients: "100% Chicken Thigh with Bone",
            packaging: "Tray Pack with Plastic Wrap"
        },
        benchmarks: {
            good: "More flavorful: Higher fat content means juicier meat",
            poor: "Higher in fat: 13g fat per serving"
        }
    },
    ground_chicken: {
        name: "Ground Chicken",
        category: "meats",
        price: "₱245.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 86,
        ratings: "9,876",
        flavors: ["Mild", "Versatile", "Lean"],
        nutrition: {
            calories: 176,
            protein: 26,
            carbs: 0,
            fats: 8,
            vitamins: 5.5,
            minerals: 7.0,
            overall: 8.3
        },
        details: {
            origin: "Local Farms",
            shelfLife: "1-2 days refrigerated, 3 months frozen",
            servingSize: "100g (3.5 oz)",
            ingredients: "100% Ground Chicken (mix of white and dark meat)",
            packaging: "Vacuum Sealed Package"
        },
        benchmarks: {
            good: "Versatile: Can be used in numerous recipes",
            poor: "Shorter shelf life than whole cuts"
        }
    },
    thin_sliced_chicken_breast: {
        name: "Thin-sliced Chicken Breast",
        category: "meats",
        price: "₱295.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 89,
        ratings: "8,765",
        flavors: ["Mild", "Clean", "Lean"],
        nutrition: {
            calories: 165,
            protein: 31,
            carbs: 0,
            fats: 3.6,
            vitamins: 5.5,
            minerals: 7.0,
            overall: 8.8
        },
        details: {
            origin: "Local Farms",
            shelfLife: "2 days refrigerated, 4 months frozen",
            servingSize: "100g (3.5 oz)",
            ingredients: "100% Chicken Breast",
            packaging: "Vacuum Sealed Package"
        },
        benchmarks: {
            good: "Quick cooking: Cooks in half the time of regular breast",
            poor: "Easy to overcook: Requires careful monitoring"
        }
    },
    diced_chicken_breast: {
        name: "Diced Chicken Breast",
        category: "meats",
        price: "₱285.00",
        release: "Always Available",
        image: "/api/placeholder/200/150",
        score: 87,
        ratings: "7,654",
        flavors: ["Mild", "Clean", "Lean"],
        nutrition: {
            calories: 165,
            protein: 31,
            carbs: 0,
            fats: 3.6,
            vitamins: 5.5,
            minerals: 7.0,
            overall: 8.7
        },
        details: {
            origin: "Local Farms",
            shelfLife: "1-2 days refrigerated, 4 months frozen",
            servingSize: "100g (3.5 oz)",
            ingredients: "100% Chicken Breast",
            packaging: "Vacuum Sealed Package"
        },
        benchmarks: {
            good: "Pre-cut convenience: Ready for stir-fries and quick meals",
            poor: "Premium price: 3-5% more than whole breast per weight"
        }
    }
};

function filterProductsByCategory(category) {
    const options1 = document.querySelectorAll('#product1 optgroup option');
    const options2 = document.querySelectorAll('#product2 optgroup option');
    
    if (!options1.length || !options2.length) return;
    
    if (category === 'all') {
        // Show all options
        options1.forEach(option => option.style.display = '');
        options2.forEach(option => option.style.display = '');
        return;
    }
    
    // Filter options based on category
    options1.forEach(option => {
        const optgroup = option.parentNode;
        const optgroupLabel = optgroup.label.toLowerCase();
        
        if (category === optgroupLabel.toLowerCase()) {
            option.style.display = '';
        } else {
            option.style.display = 'none';
        }
    });
    
    options2.forEach(option => {
        const optgroup = option.parentNode;
        const optgroupLabel = optgroup.label.toLowerCase();
        
        if (category === optgroupLabel.toLowerCase()) {
            option.style.display = '';
        } else {
            option.style.display = 'none';
        }
    });
}

function compareProducts() {
    const product1Select = document.getElementById('product1');
    const product2Select = document.getElementById('product2');
    const comparisonResults = document.getElementById('comparison-results');
    const nutritionalComparison = document.getElementById('nutritional-comparison');
    
    if (!product1Select || !product2Select || !comparisonResults || !nutritionalComparison) return;
    
    const product1Id = product1Select.value;
    const product2Id = product2Select.value;
    
    if (!product1Id || !product2Id) {
        alert('Please select two products to compare');
        return;
    }
    
    // Fixed: Changed productData to productDatabase
    const product1 = productDatabase[product1Id];
    const product2 = productDatabase[product2Id];
    
    // Add console logging for debugging
    console.log("Product 1:", product1Id, product1);
    console.log("Product 2:", product2Id, product2);
    
    // Make sure products exist before proceeding
    if (!product1 || !product2) {
        console.error("One or both products not found in database");
        alert('Error: Could not find product data');
        return;
    }
    
    // Update product 1 card
    updateProductCard('product1-card', product1);
    
    // Update product 2 card
    updateProductCard('product2-card', product2);
    
    // Update nutritional comparison
    updateNutritionalComparison(product1, product2);
    
    // Show comparison results
    comparisonResults.style.display = 'flex';
    nutritionalComparison.style.display = 'block';
    
    // Calculate and display differences
    calculateDifferences(product1, product2);
}

function updateProductCard(cardId, product) {
    const card = document.getElementById(cardId);
    if (!card) {
        console.error(`Card element with id '${cardId}' not found`);
        return;
    }
    
    // Update product name
    const nameElement = card.querySelector('.product-name');
    if (nameElement) nameElement.textContent = product.name;
    
    // Update score
    const scoreElement = card.querySelector('.product-score');
    if (scoreElement) scoreElement.textContent = product.score;
    
    // Update image
    const imageElement = card.querySelector('.product-image img');
    if (imageElement) {
        imageElement.src = product.image;
        imageElement.alt = product.name;
    }
    
    // Update price
    const priceElement = card.querySelector('.product-price');
    if (priceElement) priceElement.textContent = product.price;
    
    // Update release date
    const releaseElement = card.querySelector('.product-release');
    if (releaseElement) releaseElement.textContent = `Release date: ${product.release}`;
    
    // Update flavors
    const flavorsContainer = card.querySelector('.flavors');
    if (flavorsContainer) {
        flavorsContainer.innerHTML = '';
        
        product.flavors.forEach(flavor => {
            const flavorTag = document.createElement('div');
            flavorTag.className = 'flavor-tag';
            flavorTag.textContent = flavor;
            flavorsContainer.appendChild(flavorTag);
        });
    }
    
    // Update benchmarks
    const benchmarksContainer = card.querySelector('.benchmarks');
    if (benchmarksContainer) {
        benchmarksContainer.innerHTML = `
            <div>User Ratings: <strong>${product.ratings}</strong></div>
            <div class="good-bench">Great bench: ${product.benchmarks.good}</div>
            <div class="poor-bench">Poor bench: ${product.benchmarks.poor}</div>
        `;
    }
}

function updateNutritionalComparison(product1, product2) {
    const nutritionalComparisonDiv = document.getElementById('nutritional-comparison');
    if (!nutritionalComparisonDiv) return;
    
    const nutritionMetrics = [
        { name: 'Calories', prop: 'calories' },
        { name: 'Protein', prop: 'protein' },
        { name: 'Carbohydrates', prop: 'carbs' },
        { name: 'Fats', prop: 'fats' },
        { name: 'Vitamins', prop: 'vitamins' },
        { name: 'Minerals', prop: 'minerals' },
        { name: 'Overall Nutritional Value', prop: 'overall' }
    ];
    
    nutritionalComparisonDiv.innerHTML = '<h3>Nutritional Comparison</h3>';
    
    nutritionMetrics.forEach(metric => {
        const diff = calculatePercentDifference(product1.nutrition[metric.prop], product2.nutrition[metric.prop]);
        const width = calculateBarWidth(diff);
        
        const metricDiv = document.createElement('div');
        metricDiv.className = 'nutrition-metric';
        
        const headerDiv = document.createElement('div');
        headerDiv.className = 'nutrition-header';
        
        const nameDiv = document.createElement('div');
        nameDiv.className = 'metric-name';
        nameDiv.textContent = metric.name;
        
        const valuesDiv = document.createElement('div');
        valuesDiv.className = 'metric-values';
        valuesDiv.innerHTML = `<span>${product1.nutrition[metric.prop]}</span> vs <span>${product2.nutrition[metric.prop]}</span>`;
        
        const diffDiv = document.createElement('div');
        diffDiv.className = diff >= 0 ? 'difference positive' : 'difference negative';
        diffDiv.textContent = diff >= 0 ? `+${diff}%` : `${diff}%`;
        
        headerDiv.appendChild(nameDiv);
        headerDiv.appendChild(valuesDiv);
        headerDiv.appendChild(diffDiv);
        
        const barContainerDiv = document.createElement('div');
        barContainerDiv.className = 'bar-container';
        
        const barDiv = document.createElement('div');
        barDiv.className = diff >= 0 ? 'nutrition-bar positive' : 'nutrition-bar negative';
        barDiv.style.width = `${Math.abs(width)}%`;
        
        barContainerDiv.appendChild(barDiv);
        
        metricDiv.appendChild(headerDiv);
        metricDiv.appendChild(barContainerDiv);
        
        nutritionalComparisonDiv.appendChild(metricDiv);
    });
}

function calculatePercentDifference(val1, val2) {
    if (val1 === 0) return val2 > 0 ? 100 : 0; // Avoid division by zero
    return Math.round(((val2 - val1) / val1) * 100);
}

function calculateBarWidth(diff) {
    // Normalize the difference to a percentage between 10 and 90
    const absDiff = Math.abs(diff);
    let width = Math.min(absDiff, 100); // Cap at 100%
    
    // Ensure minimum width for visibility
    if (width < 10) width = 10;
    
    return width;
}

function calculateDifferences(product1, product2) {
    const nutritionalComparisonDiv = document.getElementById('nutritional-comparison');
    if (!nutritionalComparisonDiv) return;
    
    // Calculate category-specific differences
    let categorySpecificComparison = '';
    
    if (product1.category !== product2.category) {
        categorySpecificComparison = `
            <div class="cross-category-comparison">
                <h3>Cross-Category Comparison: ${product1.category} vs ${product2.category}</h3>
                <p>This comparison spans different food categories, which may have inherently different nutritional profiles.</p>
            </div>
        `;
        
        // Add the category-specific comparison to the nutritional comparison div
        nutritionalComparisonDiv.insertAdjacentHTML('beforeend', categorySpecificComparison);
    }
    
    // Add additional comparison summary
    const summaryDiv = document.createElement('div');
    summaryDiv.className = 'comparison-summary';
    summaryDiv.innerHTML = `
        <h3>Comparison Summary</h3>
        <p><strong>${product1.name}</strong> vs <strong>${product2.name}</strong></p>
        <ul>
            <li>Price difference: ${compareValues(product1.price, product2.price, true)}</li>
            <li>Score difference: ${product2.score - product1.score} points</li>
            <li>Main difference: ${generateMainDifference(product1, product2)}</li>
        </ul>
    `;
    
    nutritionalComparisonDiv.appendChild(summaryDiv);
}

function compareValues(val1, val2, isPrice = false) {
    if (isPrice) {
        // Extract numeric values from price strings (assuming format like "₱89.50")
        const price1 = parseFloat(val1.replace(/[^0-9.]/g, ''));
        const price2 = parseFloat(val2.replace(/[^0-9.]/g, ''));
        const diff = price2 - price1;
        
        if (Math.abs(diff) < 0.01) return "Same price";
        
        const percentDiff = Math.round((diff / price1) * 100);
        return diff > 0 ? 
            `${val2} (${percentDiff}% more expensive)` : 
            `${val2} (${Math.abs(percentDiff)}% cheaper)`;
    }
    
    return val2 - val1;
}

function generateMainDifference(product1, product2) {
    // Find the nutrition property with the biggest percent difference
    let maxDiff = 0;
    let maxProperty = '';
    
    for (const prop in product1.nutrition) {
        const diff = Math.abs(calculatePercentDifference(product1.nutrition[prop], product2.nutrition[prop]));
        if (diff > maxDiff) {
            maxDiff = diff;
            maxProperty = prop;
        }
    }
    
    if (maxProperty) {
        const direction = product2.nutrition[maxProperty] > product1.nutrition[maxProperty] ? "higher" : "lower";
        return `${product2.name} has ${maxDiff}% ${direction} ${maxProperty} content`;
    }
    
    return "Products are nutritionally similar";
}